<template>
  <router-view/>
</template>

<style lang="less">
  @import './style/flex.css';
  @import './style/reset.css';
  @import './style/preset.css';
</style>
